<style>
   .privacy-content{
        width: 100%;
        display: inline-block;
        padding: 20px 0px;
   } 
   h2.st-p {
    font-size: 22px;
    }
   .account-wrapper {
     box-shadow: none !important;
    }
    p.st-ptext {
    font-size: 15px;
    font-weight: 500;
    padding: 10px 0px;
    line-height: 30px;
   }
</style>

<body>
    


    <!--============= Hero Section Starts Here =============-->
    <div class="hero-section st-hero">
        <div class="container">
            <!-- <ul class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li>
                    <a href="#0">Pages</a>
                </li>
                <li>
                    <span>Sign In</span>
                </li>
            </ul> -->
        </div>
        <div class="bg_img hero-bg bottom_center" ></div>
    </div>
    <!--============= Hero Section Ends Here =============-->


    <!--============= Account Section Starts Here =============-->
    <section class="account-section padding-bottom">
        <div class="container">
            <div class="account-wrapper mt--100 mt-lg--440">
                 <div class="privacy-content">
                     <h2 class="st-p">Privacy Policy</h2>
                     <p class="st-ptext">
                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                       when an unknown printer took a galley of type and scrambled it to make a type
                       specimen book. It has survived not only five centuries, but also the leap into 
                       electronic typesetting, remaining essentially unchanged. It was popularised in
                       the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                       and more recently with desktop publishing software like Aldus PageMaker including
                       versions of Lorem Ipsum.
                     </p>

                     <p class="st-ptext">
                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                       when an unknown printer took a galley of type and scrambled it to make a type
                       specimen book. It has survived not only five centuries, but also the leap into 
                       electronic typesetting, remaining essentially unchanged. It was popularised in
                       the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                       and more recently with desktop publishing software like Aldus PageMaker including
                       versions of Lorem Ipsum.
                     </p>

                     <p class="st-ptext">
                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                       when an unknown printer took a galley of type and scrambled it to make a type
                       specimen book. It has survived not only five centuries, but also the leap into 
                       electronic typesetting, remaining essentially unchanged. It was popularised in
                       the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                       and more recently with desktop publishing software like Aldus PageMaker including
                       versions of Lorem Ipsum.
                     </p>
                 </div>
            </div>
        </div>
    </section>
    <!--============= Account Section Ends Here =============-->


    