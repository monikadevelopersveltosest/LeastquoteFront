<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html>
<head>
	<title>404</title>
</head>
<body style="background: #f4fbfb;">
<div class="container">
		<div class="row text-center">
			<a href="<?php echo base_url();?>" style="width: 100%;display: inline-block;text-align: center;"><img style="width:100%;margin: 0 auto;margin-bottom: 45px;max-width: 800px;" src="<?php echo base_url().'common_assets/images/404.gif';?>" alt="404"></a>
		</div>
	</div>
   
</body>
</html>
